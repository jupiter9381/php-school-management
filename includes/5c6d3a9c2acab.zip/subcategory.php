<?php include 'header.php'; ?>


			<!-- 
				MIDDLE 
			-->
			<section id="middle">


				<!-- page title -->
				<header id="page-header">
					<h1>Sub-Category</h1>
					
				</header>
				<!-- /page title -->


				<div id="content" class="padding-30">

					
					<div id="panel-1" class="panel panel-default">
						<div class="panel-heading">
							<span class="title elipsis">
								<strong>Sub-Category</strong> <!-- panel title -->
							</span>
							<button onclick="location.href='addsubcategory.php'" class=" pull-right btn btn-warning">Add Sub-Category</button>
							</div> 	

							
						</div>

						<!-- panel content -->
						<div class="panel-body">

							<table class="table table-striped table-hover table-bordered" id="sample_editable_1">
								<thead>
									<tr>
										<th>S.no</th>
										<th>Sub-Category</th>
										<th>Category</th>
										<th>Action</th>
										
									</tr>
								</thead>
									<?php $qry= mysqli_query($db,"Select t1.*,t2.name as category_name from subcategory as t1 left join category as t2 on t1.cat_id= t2.id");
									$i=1;
									while($row= mysqli_fetch_assoc($qry))
									{
										
										?>
								<tbody>
									<tr>
										<td>
											 <?php echo $i; ?>
										</td>
										<td>
										 
											<?php echo $row['sub_cat']; ?>
											
										</td>
										<td>
											 <?php echo $row['category_name']; ?>
										</td>
										
										
										<td>
											<a class="edit" href="addsubcategory.php?id=<?php echo $row['id'];?>">
											Edit </a> &nbsp; <a class="btn btn-xs btn-danger subdelete" href="javascript:void(0);" data-id="<?php echo $row['id']; ?>">
											Delete </a>
										</td>
										
									</tr>
									
									
									
									
									
									
									
								</tbody>
									<?php $i++; } ?>
							</table>

						</div>
						<!-- /panel content -->

						<!-- panel footer -->
						<div class="panel-footer">

						</div>
						<!-- /panel footer -->

					</div>
					<!-- /PANEL -->

				</div>
			</section>
			<!-- /MIDDLE -->

		<?php include 'footer.php'; ?>